using Microsoft.AspNetCore.Mvc;
using TaskAPI.Data;
using TaskAPI.Models;

namespace TaskAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetTasks()
        {
            // TODO: Implement GET /api/tasks
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<TaskItem>> CreateTask(TaskItem task)
        {
            // TODO: Implement POST /api/tasks
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateStatus(Guid id, [FromBody] TaskStatus status)
        {
            // TODO: Implement PUT /api/tasks/{id}
            return Ok();
        }
    }
}
