using System.ComponentModel.DataAnnotations;

namespace TaskAPI.Models
{
    public class TaskItem
    {
        // TODO: Add necessary fields
    }
}
